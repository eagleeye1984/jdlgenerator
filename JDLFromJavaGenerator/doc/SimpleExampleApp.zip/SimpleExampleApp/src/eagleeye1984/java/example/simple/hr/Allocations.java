package eagleeye1984.java.example.simple.hr;

import eagleeye1984.java.example.simple.entities.Person;
import eagleeye1984.java.example.simple.entities.group.DepProject;
import eagleeye1984.java.example.simple.entities.group.Department;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Allocations {
    private final Map<DepProject, List<Person>> projectDevelopers = new HashMap<>();

    public Map<DepProject, List<Person>> getProjectDevelopers() {
        return projectDevelopers;
    }

    static class SomeInnerClass {
        private enum InnerEnum {
            ONE, TWO, THREE
        }

        private String someOtherString;
        private InnerEnum innerEnum;
        private OutterEnum outterEnum;

        public String getSomeOtherString() {
            return someOtherString;
        }

        public void setSomeOtherString(String someOtherString) {
            this.someOtherString = someOtherString;
        }

        public InnerEnum getInnerEnum() {
            return innerEnum;
        }

        public void setInnerEnum(InnerEnum innerEnum) {
            this.innerEnum = innerEnum;
        }
    }
}

enum OutterEnum {
    D1, D2, D3, D4
}
