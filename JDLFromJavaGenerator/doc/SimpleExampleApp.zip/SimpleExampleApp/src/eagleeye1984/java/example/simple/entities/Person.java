package eagleeye1984.java.example.simple.entities;

import eagleeye1984.java.example.simple.entities.group.Department;

public class Person {
    private Integer personId;
    private String name;
    private Long age;
    private int salaryLevel;
    private Department department;

    public Person(Integer personId, String name, Long age, int salaryLevel, Department department) {
        this.personId = personId;
        this.name = name;
        this.age = age;
        this.salaryLevel = salaryLevel;
        this.department = department;
    }

    public Integer getPersonId() {
        return personId;
    }

    public void setPersonId(Integer personId) {
        this.personId = personId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Long getAge() {
        return age;
    }

    public void setAge(Long age) {
        this.age = age;
    }

    public int getSalaryLevel() {
        return salaryLevel;
    }

    public void setSalaryLevel(int salaryLevel) {
        this.salaryLevel = salaryLevel;
    }

    public Department getDepartment() {
        return department;
    }

    public void setDepartment(Department department) {
        this.department = department;
    }
}
