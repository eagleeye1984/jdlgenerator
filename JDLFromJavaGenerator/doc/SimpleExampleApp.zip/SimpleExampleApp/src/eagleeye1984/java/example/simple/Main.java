package eagleeye1984.java.example.simple;

import eagleeye1984.java.example.simple.entities.Person;
import eagleeye1984.java.example.simple.entities.group.DepProject;
import eagleeye1984.java.example.simple.entities.group.Department;
import eagleeye1984.java.example.simple.entities.group.ProjectType;
import eagleeye1984.java.example.simple.hr.Allocations;

import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        Department skodaAutoDep = new Department(1L, "Skoda Auto dep");
        DepProject depProject = new DepProject(1, "Car vision", "Let the car see", ProjectType.AUTOMOTIVE, skodaAutoDep);
        Person developer1 = new Person(2, "Person 2", 33L, 10, skodaAutoDep);

        Allocations allocations = new Allocations();
        allocations.getProjectDevelopers().computeIfAbsent(depProject, key -> new ArrayList<>()).add(developer1);
    }
}
