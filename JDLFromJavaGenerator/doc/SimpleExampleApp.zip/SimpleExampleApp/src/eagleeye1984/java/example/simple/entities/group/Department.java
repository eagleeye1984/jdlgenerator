package eagleeye1984.java.example.simple.entities.group;

public class Department {
    private Long depId;
    private String depName;

    public Department(Long depId, String depName) {
        this.depId = depId;
        this.depName = depName;
    }

    public Long getDepId() {
        return depId;
    }

    public void setDepId(Long depId) {
        this.depId = depId;
    }

    public String getDepName() {
        return depName;
    }

    public void setDepName(String depName) {
        this.depName = depName;
    }
}
