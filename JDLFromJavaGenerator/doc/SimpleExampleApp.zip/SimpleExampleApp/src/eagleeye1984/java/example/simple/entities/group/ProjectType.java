package eagleeye1984.java.example.simple.entities.group;

public enum ProjectType {
    AUTOMOTIVE, MACHINE_LEARNING
}
